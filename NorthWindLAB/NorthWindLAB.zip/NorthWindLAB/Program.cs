﻿//Main Method
//Amanda Eng




//Ignore the following code, it was used to practice













/*
using NorthWindLAB;

//instance variables



Animal aAnimal1 = new Animal();

Animal aAnimal2 = new Animal();

Aniaml aAnimal3 = new Animal();

aAnimal1.Name = "sammy";


//List

List<Animal> aListAnimals = new List<Animal> ();



List<Animal> aListAnimals = new List<Animal>();

List <Animal> a ListAnimals = new List<Animal>();




List<Aniaml> aListAnimals = new List<Animal>();

//Add to list

aListAnimals.Add(aAnimal1);
aListAnimals.Add(aAnimal2);
aListAnimals.Add(aAnimal3);



aListAnimals.Add(aAnimal4);

foreach (var s in aListAnimals)
{
    Console.WriteLine(s.ToString());
    Console.WriteLine("\n");

}


//mia program
//Amanda Eng

using Animal;

//instance varaibles

Animal aAnimal1 = new Animal();
Animal1 aAnimal2 = new Animal1();


aAnimal1.Weight = 1.5;

//List!

List<Animal> aListAnimals = new List<Animal>();

//add list

aListAnimals.Add(aAnimal1);
aListOfAnimals.Add(aAnimal2);

//Loop through the list and print them all out

foreach ( var s in aListOfAnimals)
{
    ConsoleWriteLine(s.ToString());
    ConsoleWriteLine("\n\n");
}




//instance variables

Category aCategory1 = new Cateogry();
Category aCategory2 = new Category();
Category aCategory3 = new Category();
Category aCategory4 = new Category();
Category aCategory5 = new Category();
Category aCategory6 = new Category();

aCategory1.CategoryName = "yes";


//list

List<Category> aListCategories = new List<Category>();

//Add list

aListCategories.Add(aCategory1);
aListCategories.Add(aCategory2);
aListCategories.Add(aCategory3);
aListCategories.Add(aCategory4);
aListCategories.Add(aCategory5);
aListCategories.Add(aCategory6);

//Lopp through everything in the list and print it out

foreach ( var in s aListCategories)
{
    ConsoleWriteLine(s.ToString());
    ConsoleWriteLiNE("\n\n");
}


foreach ( var in s aListCustomers)
{
    ConsoleWriteLine(s.ToString());
    ConsoleWriteLine("\n\n");
}

foreach ( var in s aListEmployees)
{
    ConsoleWriteLine(s.ToString());
    ConsoleWriteLine("\n\n");
}


List<Category> aListCategories = new List<Category> < Category > ();

*/